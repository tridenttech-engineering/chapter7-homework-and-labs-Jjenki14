//Lab7-3.cpp - calculates the average number of text
//messages sent each day for 7 days
//Created/revised by <JeJuan Jenkins> on <July 21, 2024>

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{	

    return 0;
}   //end of main function