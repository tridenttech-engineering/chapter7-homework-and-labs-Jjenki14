//Lab7-1.cpp - calculates the average number of text
//messages sent each day for 7 days
//Created/revised by <JeJuan Jenkins> on <July 21, 2024>

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{	
    int day = 0; 
    int totalTexts = 0;
    int dailyTexts = 0;
    double average = 0.0;

    for (; day < 8; day += 1) 
        {
            cout << "Enter the number of texts for day " << day + 1 << ": ";
            cin >> dailyTexts; 
            totalTexts += dailyTexts;
        }//end for 
    average = static_cast<double>(totalTexts) / day;
    cout << fixed << setprecision(0);
    cout << "You sent approxamitaley: " << average << " text messages per day." << endl;
   
        
        return 0;
}   //end of main function
