//Lab7-3.cpp - calculates the average number of text
//messages sent each day for 7 days
//Created/revised by <JeJuan Jenkins> on <July 21, 2024>
 
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{	
int day = 1; 
    int text = 0;
    int dailyText = 0;
    double avgTexts = 0.0;

    while (day < 8)
        {
            cout << "Enter the number of texts for day " << day << ": ";
            cin >> dailyText;
            text += dailyText;
            day += 1;
        }//end while 

    avgTexts = static_cast<double>(text) / (day-1);
    cout << fixed << setprecision(0);
    cout << endl << "You sent approxamitaley: " << avgTexts << " text messages per day." << endl;

    return 0; 
}//end of main function 